import AppRoute from "./routes/AppRoute";


function App() {
  return (

    <>
   < AppRoute/>
    </>
  );
}

export default App;
